from django.contrib import admin
from django.contrib.admin import AdminSite
from django.utils.html import format_html
from .models import Continent, Country
from .forms import CountryForm

# 1. Custom Admin Site Configuration
class SAFAdminSite(AdminSite):
    """Custom admin site with SAFA branding and security"""
    site_header = "SAFA Global Administration"
    site_title = "SAFA Admin Portal"
    index_title = "Dashboard"


    def has_permission(self, request):
        """Ensure only active staff can access"""
        return request.user.is_active and request.user.is_staff

# 2. Instantiate the custom admin
safa_admin_site = SAFAdminSite(name='safadmin')

# 3. Continent Admin
class ContinentAdmin(admin.ModelAdmin):
    list_display = ('name', 'code', 'world_body', 'sport_code',
                   'cont_federation', 'fedabrev', 'is_active', 'display_logo')
    list_editable = ('is_active',)
    search_fields = ('name', 'code', 'world_body', 'sport_code',
                    'cont_federation', 'fedabrev')
    actions = ['activate_continents', 'deactivate_continents']
    ordering = ('name',)
    list_per_page = 20

    def activate_continents(self, request, queryset):
        queryset.update(is_active=True)
    activate_continents.short_description = "Activate selected continents"

    def deactivate_continents(self, request, queryset):
        queryset.update(is_active=False)
    deactivate_continents.short_description = "Deactivate selected continents"

    def display_logo(self, obj):
        return format_html(
            '<img src="{}" style="height:30px;border-radius:4px"/>',
            obj.logo.url
        ) if obj.logo else "-"
    display_logo.short_description = 'Logo'

# 4. Country Admin
class CountryAdmin(admin.ModelAdmin):
    form = CountryForm
    list_display = ('name', 'code', 'continent_with_logo', 'display_flag')
    list_filter = ('continent',)
    search_fields = ('name', 'code', 'continent__name')
    ordering = ('name',)
    list_select_related = ('continent',)
    list_per_page = 25

    def continent_with_logo(self, obj):
        if obj.continent.logo:
            return format_html(
                '{} <img src="{}" style="height:20px;vertical-align:middle">',
                obj.continent.name,
                obj.continent.logo.url
            )
        return obj.continent.name
    continent_with_logo.short_description = 'Continent'
    continent_with_logo.admin_order_field = 'continent__name'

    def display_flag(self, obj):
        return format_html(
            '<img src="{}" style="height:20px;border:1px solid #ddd">',
            obj.flag.url
        ) if obj.flag else "-"
    display_flag.short_description = 'Flag'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('continent')

# 5. Register models with custom admin
safa_admin_site.register(Continent, ContinentAdmin)
safa_admin_site.register(Country, CountryAdmin)

